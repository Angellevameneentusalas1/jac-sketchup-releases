﻿#Requires -Version 5.1
# JAC SketchUp MCP — instalador para Windows.
# Uso: INSTALAR.bat (instalar)  |  DESINSTALAR.bat (quitar el plugin y la entrada de Claude).
param([switch]$Desinstalar)

$ErrorActionPreference = 'Stop'
$Version    = '0.5.0'
$ServerKey  = 'jac-sketchup'
$Here       = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDir = Join-Path $env:LOCALAPPDATA 'JAC SketchUp MCP'
$Rbz        = Join-Path $Here "mcp_for_sketchup_v$Version.rbz"
$Whl        = Join-Path $InstallDir "jac_sketchup_mcp-$Version-py3-none-any.whl"

function Write-Step([string]$Texto) { Write-Host "`n==> $Texto" -ForegroundColor Cyan }

function Get-PluginDirs {
    $root = Join-Path $env:APPDATA 'SketchUp'
    if (-not (Test-Path $root)) { return @() }
    return @(Get-ChildItem $root -Directory -Filter 'SketchUp 20*' |
        ForEach-Object { Join-Path $_.FullName 'SketchUp\Plugins' })
}

function Get-ConfigFiles {
    $files = @()
    $files += Join-Path $env:APPDATA 'Claude\claude_desktop_config.json'
    $files += @(Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Claude-Data') -Directory -ErrorAction SilentlyContinue |
        ForEach-Object { Join-Path $_.FullName 'claude_desktop_config.json' })
    return @($files | Where-Object { Test-Path $_ } | Select-Object -Unique)
}

function Get-Uvx {
    $cmd = Get-Command uvx.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $local = Join-Path $env:USERPROFILE '.local\bin\uvx.exe'
    if (Test-Path $local) { return $local }
    return $null
}

function Save-Json([string]$Ruta, $Objeto) {
    $json = $Objeto | ConvertTo-Json -Depth 20
    [System.IO.File]::WriteAllText($Ruta, $json, (New-Object System.Text.UTF8Encoding($false)))
}

function Set-ClaudeEntry([string]$Ruta, [string]$Uvx, [bool]$Quitar) {
    $copia = "$Ruta.bak-$(Get-Date -Format yyyyMMdd-HHmmss)"
    Copy-Item $Ruta $copia
    $cfg = Get-Content $Ruta -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $cfg.PSObject.Properties['mcpServers']) {
        $cfg | Add-Member -NotePropertyName mcpServers -NotePropertyValue ([pscustomobject]@{})
    }
    $servers = $cfg.mcpServers
    # Quitar la entrada del fork anterior (sketchup-mcp2 / jac-sketchup-mcp) para no duplicar el servidor.
    foreach ($p in @($servers.PSObject.Properties)) {
        if ($p.Name -eq 'sketchup' -and ($p.Value.args -join ' ') -match 'sketchup-mcp2|jac-sketchup-mcp') {
            $servers.PSObject.Properties.Remove('sketchup')
        }
    }
    if ($Quitar) {
        if ($servers.PSObject.Properties[$ServerKey]) { $servers.PSObject.Properties.Remove($ServerKey) }
    } else {
        $entrada = [pscustomobject]@{ command = $Uvx; args = @('--from', $Whl, 'jac-sketchup-mcp') }
        if ($servers.PSObject.Properties[$ServerKey]) { $servers.PSObject.Properties.Remove($ServerKey) }
        $servers | Add-Member -NotePropertyName $ServerKey -NotePropertyValue $entrada
    }
    Save-Json $Ruta $cfg
    Write-Host "   Configuración actualizada: $Ruta (copia: $copia)"
}

function Remove-Plugin([string]$Dir) {
    Remove-Item (Join-Path $Dir 'mcp_for_sketchup.rb') -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $Dir 'mcp_for_sketchup') -Recurse -Force -ErrorAction SilentlyContinue
}

# --- Comprobaciones comunes ---
if (Get-Process -Name SketchUp -ErrorAction SilentlyContinue) {
    throw 'SketchUp está abierto. Ciérralo y vuelve a ejecutar el instalador.'
}

if ($Desinstalar) {
    Write-Step 'Desinstalando JAC SketchUp MCP'
    foreach ($d in Get-PluginDirs) { Remove-Plugin $d; Write-Host "   Plugin quitado de: $d" }
    foreach ($c in Get-ConfigFiles) { Set-ClaudeEntry $c $null $true }
    if (Test-Path $InstallDir) { Remove-Item $InstallDir -Recurse -Force }
    Write-Host "`nListo. Reinicia Claude Desktop."
    Read-Host 'Pulsa Enter para salir' | Out-Null
    return
}

if (-not (Test-Path $Rbz)) { throw "No encuentro $Rbz. Extrae el ZIP completo antes de instalar." }
if (-not (Test-Path (Join-Path $Here "jac_sketchup_mcp-$Version-py3-none-any.whl"))) {
    throw 'No encuentro el wheel de Python dentro del ZIP.'
}

# --- 1. uv (provee uvx, que Claude Desktop usa para arrancar el servidor) ---
Write-Step 'Comprobando uv'
$uvx = Get-Uvx
if (-not $uvx) {
    Write-Host '   uv no está instalado. Lo instalo desde el sitio oficial de Astral.'
    Invoke-Expression (Invoke-RestMethod 'https://astral.sh/uv/install.ps1')
    $uvx = Get-Uvx
    if (-not $uvx) { throw 'No pude instalar uv. Instálalo a mano desde https://docs.astral.sh/uv/ y vuelve a ejecutar.' }
}
Write-Host "   uvx: $uvx"

# --- 2. Copiar el wheel ---
Write-Step 'Copiando el servidor de Python'
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item (Join-Path $Here "jac_sketchup_mcp-$Version-py3-none-any.whl") $Whl -Force

# --- 3. Plugin de SketchUp ---
Write-Step 'Instalando el plugin en SketchUp'
$dirs = Get-PluginDirs
if ($dirs.Count -eq 0) {
    throw 'No encuentro SketchUp instalado (%APPDATA%\SketchUp\SketchUp 20xx). Abre SketchUp una vez y vuelve a ejecutar.'
}
$zipTemp = Join-Path $env:TEMP "jac-sketchup-mcp-$Version.zip"
Copy-Item $Rbz $zipTemp -Force
foreach ($d in $dirs) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
    Remove-Plugin $d
    Expand-Archive -Path $zipTemp -DestinationPath $d -Force
    Write-Host "   Plugin instalado en: $d"
}
Remove-Item $zipTemp -Force

# --- 4. Claude Desktop ---
Write-Step 'Configurando Claude Desktop'
$configs = Get-ConfigFiles
if ($configs.Count -eq 0) {
    $configs = @(Join-Path $env:APPDATA 'Claude\claude_desktop_config.json')
    New-Item -ItemType Directory -Force -Path (Split-Path $configs[0]) | Out-Null
    Save-Json $configs[0] ([pscustomobject]@{ mcpServers = [pscustomobject]@{} })
}
foreach ($c in $configs) { Set-ClaudeEntry $c $uvx $false }

Write-Host "`nListo. Pasos finales:"
Write-Host '  1. Abre SketchUp: Extensiones → MCP Server → Start Server.'
Write-Host '  2. Reinicia Claude Desktop por completo (cerrarlo desde la bandeja).'
Read-Host "`nPulsa Enter para salir" | Out-Null
