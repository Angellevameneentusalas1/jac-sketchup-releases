@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar-JAC-SketchUp-MCP.ps1" -Desinstalar
if errorlevel 1 pause
