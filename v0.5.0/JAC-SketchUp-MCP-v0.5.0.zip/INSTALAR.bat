@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar-JAC-SketchUp-MCP.ps1"
if errorlevel 1 pause
