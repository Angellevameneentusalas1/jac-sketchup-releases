"""SketchUp MCP entry point.

The actual ``FastMCP`` instance and ``server_lifespan`` live in
``jac_sketchup_mcp.app`` (which also triggers tool registration via
``jac_sketchup_mcp.tools`` side-effect import).
"""
from jac_sketchup_mcp.app import mcp


def main() -> None:
    """CLI entry point: ``jac-sketchup-mcp`` and ``python -m jac_sketchup_mcp``."""
    mcp.run()


if __name__ == "__main__":
    main()
