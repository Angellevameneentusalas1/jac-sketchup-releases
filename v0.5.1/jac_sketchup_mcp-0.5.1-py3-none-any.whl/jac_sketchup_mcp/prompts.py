"""MCP prompts for the MCP Server for SketchUp.

Imported for its side effect (FastMCP decorator registration). See
``app.py`` — the import sits next to ``import jac_sketchup_mcp.tools``.
"""
from jac_sketchup_mcp.app import mcp

_STRATEGY_TEXT = """\
You are working with a SketchUp model through the sketchup-mcp server.
Follow this strategy to be effective and avoid common pitfalls.

# 1. Pre-flight — ALWAYS start with
- get_model_info() — units, model bbox, layer list, total entity count.
- If the user references existing geometry: list_components or
  find_components(name=...) to locate IDs (paginated: check "truncated"
  and page with offset/limit).
- For visual context after major changes:
  get_viewport_screenshot(view_preset="iso", zoom_extents=true).

# 2. Tool priority
1. Typed tools first — create_component, transform_component,
   set_material, boolean_operation, chamfer_edge, fillet_edge,
   create_mortise_tenon, create_dovetail, create_finger_joint,
   create_layer, delete_component. They handle units, transactions,
   and edge cases.
2. eval_ruby ONLY when typed tools cannot express the operation
   (custom curves, Follow Me, complex transformations,
   ComponentDefinition manipulation, layer attributes).
3. Never use eval_ruby for things a typed tool already does — you
   lose validation, mm-conversion, and atomic undo.

# 3. Conventions
- ALL linear dimensions are millimeters at the MCP boundary.
  SketchUp's Ruby API uses inches internally; the server converts.
- ALL angles are degrees.
- transform_component.position is an ABSOLUTE target: the entity's
  bbox-min corner lands exactly there (same anchor as
  create_component.position), applied AFTER rotation/scale — the
  bbox-min promise holds for combined calls too. rotation/scale are
  relative, about the bbox center.
- Entity IDs: pass them back exactly as returned — integer or string,
  both are accepted by every id parameter.
- New geometry lives inside SketchUp Groups so it can be moved/deleted
  as a unit.
- create_component minimum dimension: 0.1 mm for cube, 1.0 mm for
  curved types; defaults are a 100 mm cube.
- create_component accepts an optional name — set it so
  find_components can locate the part later.

# 4. After every mutation — verify
- Geometry, material, boolean, and edge tools return
  {id, name, type, bbox_mm} (edge tools add edges_*/stats). bbox_mm is null
  when the entity ended up with no geometry (e.g. a boolean difference
  consumed the whole body) — treat null as "inspect what happened", not as
  an error. When bbox_mm is present, read it to confirm the result matches
  the intent before the next step (and to relocate the entity if its id
  becomes stale after destructive operations).
- Joinery tools return ONE OBJECT PER BOARD — {mortise, tenon} /
  {tail, pin} / {board1, board2}, each {id, name, type, bbox_mm} — plus
  boolean_cuts {attempted, failed}: treat failed > 0 as a partial failure
  and verify via bbox_mm.
- Other tools — delete_component, create_layer, undo, list/find
  queries, get_model_info, get_selection — have their own response
  shapes; see the tool docs.
- For visual confirmation across multiple parts:
  get_viewport_screenshot(view_preset="iso", zoom_extents=true).

# 5. Error recovery
- If a mutation produced wrong geometry — call undo immediately, then
  retry with corrected parameters. Do not pile up bad geometry hoping
  to fix it later.
- boolean_operation, chamfer_edge, fillet_edge are unreliable on
  non-manifold meshes. If they fail, try with simpler input or use
  eval_ruby for a manual workaround.

# 6. Known traps
- Group#subtract is REVERSED: A.subtract(B) returns B - A. Inside
  eval_ruby, to get "target minus tool", call tool.subtract(target).
- Sketchup::Model#undo does not exist. The undo MCP tool uses
  Sketchup.send_action("editUndo:") internally — just call it.
- Layers in SketchUp are visibility flags, not folders. Adding an
  entity to a layer doesn't move it in the hierarchy.

# 7. Joinery defaults
For mortise/tenon/dovetail/finger joints, when the user doesn't
specify:
- joint dimensions ≈ 0.3-0.5 × board thickness;
- number of fingers/tails: 3-5 for typical drawer-width boards
  (200-400 mm);
- if uncertain, ASK before generating — joints are hard to fix after
  the fact without scrapping the boards.

# 8. eval_ruby gate
eval_ruby ships enabled, but the user can close the gate in the
SketchUp extension's Settings. If a call to eval_ruby returns a string
starting with "eval_ruby is disabled.", that is not a failure: it is
the extension's actionable instruction for the user. Surface the full
message to the user verbatim — do not paraphrase, do not retry the same
code, do not silently fall back to typed tools without telling the user
that eval was unavailable. The user can enable Ruby evaluation in
Plugins → MCP Server → Settings... — the checkbox is «Enable Ruby
evaluation».
"""


@mcp.prompt(
    name="sketchup_modeling_strategy",
    description=(
        "How to use SketchUp MCP tools effectively: pre-flight checks, "
        "typed-tools-vs-eval_ruby priority, units/angles conventions, "
        "verification after mutations, error recovery, known traps."
    ),
)
def sketchup_modeling_strategy() -> str:
    return _STRATEGY_TEXT
